#version 330

#define FLAG_BIT (1 << 23)
#define X(x) ((x) & 8191)
#define TYPE(x) ((x) >> 13)
#define NEGATION_COMPENSATION (1 << 10)

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec2 ui = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));

    vec4 color = Color;

    if (pos.x > 0) {
        int x = int(pos.x);
        if ((x & FLAG_BIT) == FLAG_BIT) {
            x &= ~FLAG_BIT;

            int anchor = TYPE(x);
            x = X(x) - NEGATION_COMPENSATION;

            float relativeX = 0.0;
            float relativeY = 0.0;
            int offsetX = 0;
            int offsetY = 0;

            switch (anchor) {
/* anchors substitution */
            }

            pos.x = float(x) + (relativeX - 0.5) * ui.x + offsetX;
            pos.y += (relativeY * ui.y) - 7.0 + offsetY;
        }
    }

    vertexColor = color * texelFetch(Sampler2, UV2 / 16, 0);
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);

    texCoord0 = UV0;
}
